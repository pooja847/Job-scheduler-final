const express = require("express");
const cors = require("cors");
const axios = require("axios");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

const WEBHOOK_URL = "https://webhook.site/YOUR-ID-HERE";

app.post("/jobs", (req, res) => {
  const { taskName, payload, priority } = req.body;
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO jobs (taskName, payload, priority, status, createdAt, updatedAt)
     VALUES (?, ?, ?, 'pending', ?, ?)`,
    [taskName, JSON.stringify(payload), priority, now, now],
    function () {
      res.json({ id: this.lastID });
    }
  );
});

app.get("/jobs", (req, res) => {
  db.all("SELECT * FROM jobs ORDER BY id DESC", [], (err, rows) => {
    res.json(rows);
  });
});

app.get("/jobs/:id", (req, res) => {
  db.get("SELECT * FROM jobs WHERE id=?", [req.params.id], (err, row) => {
    res.json(row);
  });
});

app.post("/run-job/:id", (req, res) => {
  const id = req.params.id;
  const now = new Date().toISOString();
  db.run("UPDATE jobs SET status='running', updatedAt=? WHERE id=?", [now, id]);

  setTimeout(async () => {
    const completedAt = new Date().toISOString();
    db.get("SELECT * FROM jobs WHERE id=?", [id], async (err, job) => {
      db.run("UPDATE jobs SET status='completed', updatedAt=? WHERE id=?", [completedAt, id]);
      try {
        await axios.post(WEBHOOK_URL, {
          jobId: job.id,
          taskName: job.taskName,
          priority: job.priority,
          payload: JSON.parse(job.payload),
          completedAt
        });
      } catch (e) {
        console.log("Webhook failed");
      }
    });
  }, 3000);

  res.json({ message: "Job started" });
});

app.listen(5000, () => console.log("Backend running on port 5000"));