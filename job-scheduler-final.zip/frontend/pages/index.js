import { useEffect, useState } from "react";

export default function Home() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/jobs")
      .then(res => res.json())
      .then(setJobs);
  }, []);

  const runJob = (id) => {
    fetch(`http://localhost:5000/run-job/${id}`, { method: "POST" });
  };

  return (
    <div style={{padding:20}}>
      <h1>Job Dashboard</h1>
      <table border="1" width="100%">
        <thead>
          <tr><th>ID</th><th>Name</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>
          {jobs.map(j => (
            <tr key={j.id}>
              <td>{j.id}</td>
              <td>{j.taskName}</td>
              <td>{j.status}</td>
              <td><button onClick={() => runJob(j.id)}>Run</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}