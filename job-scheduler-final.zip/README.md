# Job Scheduler & Automation System

## Tech Stack
Frontend: Next.js  
Backend: Node.js, Express  
Database: SQLite  

## Features
- Create jobs
- Run jobs
- Track status
- Webhook trigger on completion

## API Endpoints
POST /jobs  
GET /jobs  
GET /jobs/:id  
POST /run-job/:id  

## AI Usage
ChatGPT (GPT-5.2) used for boilerplate and documentation.
